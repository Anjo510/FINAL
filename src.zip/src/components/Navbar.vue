<template>
<div>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
  <a class="navbar-brand" href="/">BIKERS</a>
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="/">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="/Newspage">News</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="/Members">Members</a>
    </li>
        <li class="nav-item">
      <a class="nav-link" href="/Events">Events</a>
    </li>
        <li class="nav-item">
      <a class="nav-link" href="/Signup">Signup</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="/Login">Login</a>
    </li>
    </ul>
      <form class="form-inline my-2 my-lg-0 ml-auto">
    <input class="form-control mr-sm-2" type="search">
    <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
  </form>
</nav>
</div>
</template>