<template>
<div class="whole">
    <div class="bev">
    <h1 class="ev">EVENTS</h1>

    <h2 class="evv">NO CURRENT ACTIVITIES DUE TO CORONA VIRUS!! STAY SAFE!!</h2>
    </div>
<footer id="footer"> 
   © 2020 PORAC BIKERS COMMUNITY
</footer>
</div>
</template>