<template>
  <div class="home">
    <link rel="stylesheet" href="home.css">
    link
    <br><br><br>
    <div class="homes">
      <h1>PORAC BICYCLE FRIENDLY COMMUNITY</h1>
      <img class="images" src="../assets/bike.jpg" alt="">
    </div>
    <div class="text">
      <br>
      <h5>Bicycling is more than a practical, cost-effective solution to many municipal challenges. It’s an opportunity to make your community a vibrant destination for residents and visitors — a place where people don’t just live and work, but thrive.
      <br><br>
      <h5>A cruise down Porac recreational bike trails and city streets on any given day will reveal a myriad of cyclists of all ages and abilities. It is easy to understand why – almost anyone can ride a bicycle. Cycling is a low-impact exercise, easy on the joints and knees, making it an enjoyable fitness activity for the young, elderly or anyone recovering from injury. Those already in good health can use cycling to maintain a healthy weight and help build cardiovascular endurance. Additionally, cycling presents environmental and social benefits, such as an environmentally friendly means of transportation from point A to point B as well as a prime opportunity to socialize with friends and family while enjoying the benefits of exercise.</h5>
 </h5><br>
      <h5>The Porac Bicycle Club has been touting the benefits of cycling and advocating for a more bicycle- and pedestrian-friendly Poracfield since their inception in 1972. The club formed when a group of local cyclists, inspired by the fitness craze of the 70s, opted to form a club with the goal to “promote bicycling in all of its manifestations.” Over the years, the Porac Bicycle Club has worked closely with the City of Pampanga, And the regional planning commission to support transportation infrastructure that makes central luzon a more bicycle-friendly place.</h5>
      <br>
    </div>
    <br>


    <footer class="page-footer font-small special-color-dark pt-1">
    <div class="footer-copyright text-center py-3">© 2020 SATI SATI 
    </div>
  </footer>
  </div>
</template>