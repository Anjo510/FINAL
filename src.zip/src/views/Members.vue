<template>
  <div class="members-container">
      <div class="members-explore">
        <img src="../assets/explore.jpg" alt="explore">
      </div>

      <div class="members">
        <div class="members-wrapper">
          <div class="team1 team">
            <div class="team-member t1">
              <img src="../assets/1.jpg" alt="Member1">
              <p>Name: Jeffrey Valencia <br>Address: PORAC <br>Email Address: example@gmail.com</p>

            </div>
            <div class="team-member t2">
              <img src="../assets/2.jpg" alt="Member2">
            <p>Name: Jimboy Yumul<br>Address: PORAC <br>Email Address: example@gmail.com</p>
            </div>
            <div class="team-member t3">
              <img src="../assets/3.jpg" alt="Member3">
               <p>Name: Lee Venz Ramos <br>Address: PORAC <br>Email Address: example@gmail.com</p>
            </div>
          </div>

          <div class="team2 team">
            <div class="team-member t4">
              <img src="../assets/4.jpg" alt="Member4">
               <p>Name: Anjo Maglaqui <br>Address: PORAC <br>Email Address: example@gmail.com</p>
            </div>
            <div class="team-member t5">
              <img src="../assets/5.jpg" alt="Member5">
               <p>Name: Christian Elijah Loot  <br>Address: PORAC <br>Email Address: example@gmail.com</p>
            </div>
          </div>
        </div>
      </div>
  <footer class="page-footer font-small special-color-dark pt-1">
    <div class="footer-copyright text-center py-3"> © 2020 PORAC BIKERS COMMUNITY
    </div>
  </footer>
	</div>
</template>