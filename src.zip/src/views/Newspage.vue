// NEWS
<template>
<div class="bgbg2">
  <div class="connews">
<h1 class="ef">NEWS</h1>
<p class="text-center"></p>

<div class="row">
<div class="col-mid-4">
<div class="single-blog">
<p class="blog-meta">By admin <span>December 08, 2019</span></p>
<img src="../assets/bike1.png">
<h2><a href="#">Pampanga Bike Adventure Tour</a></h2>
<p class="blog-text">Join the bigger and more exciting Pampanga Bike Adventure Tour (PBAT)<br> on December 8, 2019, 6am at the Clark Picnic Grounds.</p>
<p><a href="" class="read-more-btn">Read More</a>

<span><i class="fa fa-thumbs-o-up"></i> 102 People like, <i class="fa fa-comment-o"></i>3..</span>
</p>
</div>
</div>
<div class="col-mid-4">
    <div class="single-blog">
    <p class="blog-meta">By admin <span>May 16, 2019</span></p>
    <img src="../assets/bike2.png">
    <h2><a href="#">Clark Bicycle Ride</a></h2>
    <p class="blog-text">Kindly join our Ride that will held on Porac to Clark Pampanga<br> Ride and have fun with us RIDERS!</p>
    <p><a href="" class="read-more-btn">Read More</a>
    
    <span><i class="fa fa-thumbs-o-up"></i> 67 People like, <i class="fa fa-comment-o"></i>3..</span>
    </p>
    </div>
    </div>
    <div class="col-mid-4">
        <div class="single-blog">
        <p class="blog-meta">By admin <span>Febuary 22, 2019</span></p>
        <img src="../assets/bike3.png">
        <h2><a href="#">Miyamit Falls Porac Pampanga Ride</a></h2>
        <p class="blog-text">Come and join us Ride to Miyamit Falls!<br>where after Riding the destination, you can go for swim after!</p>
        <p><a href="" class="read-more-btn">Read More</a>
        
        <span><i class="fa fa-thumbs-o-up"></i> 89 People like, <i class="fa fa-comment-o"></i>3..</span>
        </p>
        </div>
        </div>


</div>
</div>

<footer id="footer"> 
   © 2020 PORAC BIKERS COMMUNITY
</footer>
  </div>
</template>