// LOGIN
<template>
<div class="bgbg">
    <img src="../assets/bg_login.png">
<div class="box-login">
            <h2>Login</h2>
            <form>
                <div class="inputBox">
                    <input type="text" name="" required="">
                    <label>Username</label>
                </div>
                <div class="inputBox">
                    <input type="password" name="" required="">
                    <label>Password</label>
                </div>
                <input type="submit" name="" value="Submit" style="font-family: Garamond;">
                <input type="reset" name="" value="Reset" style="font-family: Garamond;">
            </form>

        </div>
                <footer id="footerlog"> 
   © 2020 PORAC BIKERS COMMUNITY
</footer>

</div>

</template>